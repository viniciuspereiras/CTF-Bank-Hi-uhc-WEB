#!/bin/bash 

nohup bash /root/bot.sh &