import http.server
import socketserver
import os
os.system("/usr/bin/toilet -f future 'bingo.py' --filter metal --gay")
port = 8000

handler = http.server.SimpleHTTPRequestHandler

with socketserver.TCPServer(("", port), handler) as httpd:
    print("PORT:", port)
    httpd.serve_forever()
