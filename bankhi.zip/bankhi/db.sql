CREATE DATABASE login;
use login;
CREATE TABLE users(
id SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(30) NOT NULL,
pass VARCHAR(100) NOT NULL
);
insert into users (username, pass) values('admin',md5('p%S#B!nG0'));
insert into users (username, pass) values('vinicius',md5('vinicius'));


CREATE TABLE bugs(
title VARCHAR(30) NOT NULL,
description VARCHAR(200) NOT NULL,
ownusername VARCHAR(30) NOT NULL
);


insert into bugs (title, description, ownusername) values('bgp hijacking', 'bgp hijacking on index.php', 'vinicius');
-- truncate bugs;
-- select * from bugs;
-- select * from users where username = 'admin' and pass = md5('pass');
-- select * from bugs where ownusername = 'big0us';
-- truncate users;
-- select * from bugs;


-- CREATE USER 'jack'@'localhost' IDENTIFIED BY 'jack';
-- GRANT ALL PRIVILEGES ON *.* TO 'jack'@'localhost' WITH GRANT OPTION;
-- CREATE USER 'jack'@'%' IDENTIFIED BY 'jack';
-- GRANT ALL PRIVILEGES ON *.* TO 'jack'@'%' WITH GRANT OPTION;
-- FLUSH PRIVILEGES;

-- select count(*) as total from users where username = 'admin' ;
-- select * from users;
