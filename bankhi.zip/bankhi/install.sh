#!/bin/bash
export DEBIAN_FRONTEND="noninteractive"

apt update -y
apt install wget lsb-release gnupg nano toilet -y
apt install sudo -y
cd /tmp
wget https://dev.mysql.com/get/mysql-apt-config_0.8.15-1_all.deb

dpkg -i mysql-apt-config*
apt update -y
apt install -y mysql-server

mysqld_safe &
sleep 5;