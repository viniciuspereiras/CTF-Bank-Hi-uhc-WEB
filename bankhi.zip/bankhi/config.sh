#!/bin/bash
#add users
echo "Welcome to your server Ronald, your pass to you use! s3curep4ss" > /welcome.txt; chmod 777 /welcome.txt

useradd -m ronald
sudo -u ronald echo "uhc{R0n4lD_5kyW4lK3r_f1l3_upl04d}" > /home/ronald/user1.txt
sudo -u ronald chmod 0750 /home/ronald
echo 'ronald:s3curep4ss' | sudo chpasswd


useradd -m leia
sudo -u leia echo "remove your exploit! -> uhc{l31a_l1k3s_run_B1NG0_:)_}" > /home/leia/user2.txt
sudo -u leia mkdir /home/leia/scripts/
sudo -u leia chmod 0750 /home/leia
echo 'leia:BN40@_#880' | sudo chpasswd

chmod 755 /opt/bingo.py


echo "leia ALL = SETENV: NOPASSWD: /bin/sl" >> /etc/sudoers
echo "ronald ALL = (leia) SETENV: NOPASSWD:/usr/bin/python3.7 /opt/bingo.py" >> /etc/sudoers



chmod +x /bin/sl 




