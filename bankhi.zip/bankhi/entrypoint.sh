mysqld_safe &
sleep 20;

mysql -u root -prootbig0us -e "ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'rootbig0us'; flush privileges;"
echo "create database config;" | mysql -u root -prootbig0us
mysql -u root -prootbig0us config < /root/db.sql

apache2-foreground